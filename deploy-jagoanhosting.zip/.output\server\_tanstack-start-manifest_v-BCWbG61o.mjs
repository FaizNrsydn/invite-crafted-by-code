//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BCWbG61o.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "D:/invite-crafted-by-code/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-D-5FmCGf.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-D-5FmCGf.js"
		} }]
	},
	"/": {
		filePath: "D:/invite-crafted-by-code/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BYM6s2nx.js"]
	}
} });
//#endregion
export { tsrStartManifest };
