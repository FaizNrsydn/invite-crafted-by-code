import { r as __toESM } from "../_runtime.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-C-XuSua3.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Reveal({ children, delay = 0, className = "" }) {
	const ref = (0, import_react.useRef)(null);
	const [shown, setShown] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const el = ref.current;
		if (!el) return;
		const io = new IntersectionObserver((entries) => {
			if (entries[0]?.isIntersecting) {
				setShown(true);
				io.disconnect();
			}
		}, { threshold: .18 });
		io.observe(el);
		return () => io.disconnect();
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref,
		className: `reveal ${shown ? "reveal-in" : ""} ${className}`,
		style: { transitionDelay: `${delay}ms` },
		children
	});
}
var COUPLE = {
	groom: {
		name: "Harish Triyadi",
		short: "Harish",
		parents: "Putra dari Bapak Iwan Triyadi & Ibu Sumaryani"
	},
	bride: {
		name: "Fadhilah Rubab",
		short: "Fadhilah",
		parents: "Putri dari Bapak Santoso & Ibu Siti Asiah"
	}
};
var EVENT = {
	title: "Akad Nikah",
	day: "Jumat",
	dateLabel: "18 September 2026",
	timeLabel: "Pukul 14:00 WIB - Selesai",
	venue: "Kediaman Mempelai Wanita",
	address: "Blok Wage RT 001 RW 004 No. 30, Desa Sindanglaut, Kec. Lemahabang, Kab. Cirebon",
	target: /* @__PURE__ */ new Date("2026-09-18T14:00:00+07:00")
};
var MAPS_URL = "https://maps.app.goo.gl/JEtCz1PVcfy5AaYs6";
var CALENDAR_URL = "https://calendar.google.com/calendar/render?action=TEMPLATE&text=" + encodeURIComponent("Akad Nikah Harish Triyadi & Fadhilah Rubabb") + "&dates=20260918T070000Z/20260918T100000Z&details=Mohon%20doa%20restu%20atas%20pernikahan%20kami.&location=" + encodeURIComponent(`${EVENT.venue}, ${EVENT.address}`);
var QURAN = {
	text: "Dan di antara tanda-tanda kekuasaan-Nya ialah Dia menciptakan untukmu pasangan hidup dari jenismu sendiri agar kamu memperoleh ketenangan hati padanya, dan dijadikan-Nya di antaramu rasa kasih dan sayang...",
	source: "QS. Ar-Rum: 21"
};
var ACCOUNTS = [{
	bank: "BCA",
	number: "3041210069",
	holder: "Fadhilah Rubab"
}, {
	bank: "BCA",
	number: "7745382151",
	holder: "Harish Triyadi"
}];
var FAMILY = ["Kel. Besar Bapak Iwan Triyadi & Ibu Sumaryani", "Kel. Besar Bapak Abdul Wahab & Ibu Siti Asiah (Brilink)"];
var SPREADSHEET_URL = "https://script.google.com/macros/s/AKfycbxAmuInOlKZkTThrBtUmvUx93j2LU6ayBYykeD84J-sAQE8mczstSMEGTBF8FtRHU3n/exec";
function WishesForm({ onNotify }) {
	const [name, setName] = (0, import_react.useState)("");
	const [attendance, setAttendance] = (0, import_react.useState)("Hadir");
	const [message, setMessage] = (0, import_react.useState)("");
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [loadingWishes, setLoadingWishes] = (0, import_react.useState)(false);
	const [submitted, setSubmitted] = (0, import_react.useState)(false);
	const [wishes, setWishes] = (0, import_react.useState)([]);
	const loadWishesFromSheet = (0, import_react.useCallback)(async () => {
		if ("https://script.google.com/macros/s/AKfycbxAmuInOlKZkTThrBtUmvUx93j2LU6ayBYykeD84J-sAQE8mczstSMEGTBF8FtRHU3n/exec".trim() === "") return;
		try {
			setLoadingWishes(true);
			const resData = await (await fetch(SPREADSHEET_URL)).json();
			if (resData && Array.isArray(resData.data)) setWishes(resData.data);
		} catch (err) {
			console.warn("Belum dapat memuat pesan dari spreadsheet:", err);
		} finally {
			setLoadingWishes(false);
		}
	}, []);
	(0, import_react.useEffect)(() => {
		try {
			localStorage.removeItem("wedding_wishes");
		} catch {}
		loadWishesFromSheet();
	}, [loadWishesFromSheet]);
	const handleSubmit = async (e) => {
		e.preventDefault();
		if (!name.trim() || !message.trim()) {
			onNotify?.("Mohon lengkapi nama dan pesan Anda");
			return;
		}
		setLoading(true);
		const timeLabel = (/* @__PURE__ */ new Date()).toLocaleString("id-ID", {
			dateStyle: "medium",
			timeStyle: "short"
		});
		const newWish = {
			id: `local-${Date.now()}`,
			name: name.trim(),
			attendance,
			message: message.trim(),
			createdAt: timeLabel
		};
		try {
			if ("https://script.google.com/macros/s/AKfycbxAmuInOlKZkTThrBtUmvUx93j2LU6ayBYykeD84J-sAQE8mczstSMEGTBF8FtRHU3n/exec".trim() !== "") {
				const formData = new URLSearchParams();
				formData.append("timestamp", timeLabel);
				formData.append("nama", name.trim());
				formData.append("kehadiran", attendance);
				formData.append("pesan", message.trim());
				await fetch(SPREADSHEET_URL, {
					method: "POST",
					mode: "no-cors",
					headers: { "Content-Type": "application/x-www-form-urlencoded" },
					body: formData.toString()
				});
			}
			setWishes((prev) => [newWish, ...prev]);
			setName("");
			setMessage("");
			setSubmitted(true);
			onNotify?.("Kesan & pesan berhasil dikirim!");
			setTimeout(() => {
				loadWishesFromSheet();
			}, 3e3);
		} catch (err) {
			console.error(err);
			onNotify?.("Gagal mengirim, mohon coba lagi nanti");
		} finally {
			setLoading(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "w-full text-left",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-2xl border border-border/75 bg-card/85 p-6 shadow-sm backdrop-blur-md",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
						className: "font-script text-3xl text-sage-deep",
						children: "Kesan & Pesan"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 font-display text-xs tracking-wide text-muted-foreground",
						children: "Sampaikan doa, kesan, dan pesan bahagia untuk kedua mempelai"
					})]
				}),
				submitted && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 rounded-xl bg-primary/10 border border-primary/20 p-3.5 text-center text-xs font-display text-sage-deep",
					children: "✨ Terima kasih banyak atas doa dan pesan hangat yang telah Anda kirimkan!"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: handleSubmit,
					className: "mt-5 space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							htmlFor: "guest-name",
							className: "block font-display text-xs uppercase tracking-wider text-muted-foreground",
							children: ["Nama Anda ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-destructive",
								children: "*"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							id: "guest-name",
							type: "text",
							required: true,
							value: name,
							onChange: (e) => setName(e.target.value),
							placeholder: "Contoh: Budi Santoso",
							className: "mt-1.5 w-full rounded-xl border border-border bg-background/80 px-4 py-2.5 font-display text-sm text-foreground placeholder:text-muted-foreground/60 focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
							htmlFor: "guest-attendance",
							className: "block font-display text-xs uppercase tracking-wider text-muted-foreground",
							children: "Konfirmasi Kehadiran"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							id: "guest-attendance",
							value: attendance,
							onChange: (e) => setAttendance(e.target.value),
							className: "mt-1.5 w-full rounded-xl border border-border bg-background/80 px-4 py-2.5 font-display text-sm text-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "Hadir",
									children: "Hadir"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "Belum Pasti",
									children: "Belum Pasti / Ragu-ragu"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "Tidak Hadir",
									children: "Tidak Hadir (Kirim Doa)"
								})
							]
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							htmlFor: "guest-message",
							className: "block font-display text-xs uppercase tracking-wider text-muted-foreground",
							children: ["Kesan, Pesan & Doa Restu ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-destructive",
								children: "*"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							id: "guest-message",
							required: true,
							rows: 3,
							value: message,
							onChange: (e) => setMessage(e.target.value),
							placeholder: "Tuliskan ucapan dan doa Anda...",
							className: "mt-1.5 w-full resize-none rounded-xl border border-border bg-background/80 px-4 py-2.5 font-display text-sm text-foreground placeholder:text-muted-foreground/60 focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "submit",
							disabled: loading,
							className: "w-full rounded-full bg-primary px-5 py-2.5 font-display text-xs tracking-[0.22em] text-primary-foreground transition-opacity hover:opacity-90 disabled:opacity-50",
							children: loading ? "MENGIRIM..." : "KIRIM PESAN"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 border-t border-border/60 pt-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-display text-xs uppercase tracking-wider text-muted-foreground",
							children: [
								"Ucapan & Doa (",
								wishes.length,
								")"
							]
						}), loadingWishes && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-[11px] text-muted-foreground animate-pulse",
							children: "Memuat data..."
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 max-h-72 space-y-3 overflow-y-auto pr-1",
						children: wishes.length === 0 && !loadingWishes ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "rounded-xl border border-dashed border-border/80 p-4 text-center",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-xs text-muted-foreground",
								children: "Belum ada ucapan. Jadilah yang pertama memberikan doa restu!"
							})
						}) : wishes.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-xl border border-border/40 bg-background/60 p-3.5 transition-all",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-display text-sm font-semibold text-foreground",
										children: item.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `rounded-full px-2 py-0.5 font-display text-[10px] ${item.attendance === "Hadir" ? "bg-primary/15 text-sage-deep" : item.attendance === "Tidak Hadir" ? "bg-destructive/15 text-destructive" : "bg-muted text-muted-foreground"}`,
										children: item.attendance
									})]
								}),
								item.createdAt && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-[10px] text-muted-foreground/80 font-display",
									children: item.createdAt
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1.5 font-display text-xs leading-relaxed text-muted-foreground",
									children: item.message
								})
							]
						}, item.id))
					})]
				})
			]
		})
	});
}
var garden_default = "/assets/garden-Be9pKiCb.jpg";
var wisteria_default = "/assets/wisteria-BtZgViY1.png";
var mountains_default = "/assets/mountains-CwQIfVRr.jpg";
var archway_default = "/assets/archway-DFUxKrlG.jpg";
var pines_default = "/assets/pines-FZKlULXh.png";
var seal_default = "/assets/seal-B11bZQkh.png";
var MUSIC_SRC = "/music.mp3";
function Butterfly({ style }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		"aria-hidden": true,
		className: "pointer-events-none absolute",
		style,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			width: "26",
			height: "22",
			viewBox: "0 0 26 22",
			fill: "none",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M13 11C10 3 4 1 2 5c-2 4 3 8 11 6Z",
					fill: "currentColor",
					opacity: ".55"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M13 11c3-8 9-10 11-6 2 4-3 8-11 6Z",
					fill: "currentColor",
					opacity: ".4"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M13 10v8",
					stroke: "currentColor",
					strokeWidth: "1.2"
				})
			]
		})
	});
}
function Countdown() {
	const [now, setNow] = (0, import_react.useState)(() => Date.now());
	(0, import_react.useEffect)(() => {
		const id = setInterval(() => setNow(Date.now()), 1e3);
		return () => clearInterval(id);
	}, []);
	const parts = (0, import_react.useMemo)(() => {
		const diff = Math.max(0, EVENT.target.getTime() - now);
		const s = Math.floor(diff / 1e3);
		return [
			{
				v: Math.floor(s / 86400),
				l: "HARI"
			},
			{
				v: Math.floor(s % 86400 / 3600),
				l: "JAM"
			},
			{
				v: Math.floor(s % 3600 / 60),
				l: "MNT"
			},
			{
				v: s % 60,
				l: "DTK"
			}
		];
	}, [now]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex items-center justify-center gap-1",
		children: parts.map((p, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-end",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "w-[62px] text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "font-display text-4xl font-semibold tabular-nums text-sage-deep",
					children: String(p.v).padStart(2, "0")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-1 text-[10px] tracking-[0.22em] text-muted-foreground",
					children: p.l
				})]
			}), i < parts.length - 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "pb-6 text-3xl text-sage",
				children: ":"
			})]
		}, p.l))
	});
}
function Invitation() {
	const [opened, setOpened] = (0, import_react.useState)(false);
	const [playing, setPlaying] = (0, import_react.useState)(false);
	const [toast, setToast] = (0, import_react.useState)(null);
	const audioRef = (0, import_react.useRef)(null);
	const showToast = (0, import_react.useCallback)((msg) => {
		setToast(msg);
		setTimeout(() => setToast(null), 2400);
	}, []);
	const open = (0, import_react.useCallback)(() => {
		setOpened(true);
		document.body.style.overflow = "";
		const a = audioRef.current;
		if (a) {
			a.volume = .6;
			a.play().then(() => setPlaying(true)).catch(() => setPlaying(false));
		}
		setTimeout(() => window.scrollTo({ top: 0 }), 60);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!opened) document.body.style.overflow = "hidden";
		return () => {
			document.body.style.overflow = "";
		};
	}, [opened]);
	const toggleMusic = (0, import_react.useCallback)(() => {
		const a = audioRef.current;
		if (!a) return;
		if (a.paused) a.play().then(() => setPlaying(true)).catch(() => showToast("Musik latar belum tersedia."));
		else {
			a.pause();
			setPlaying(false);
		}
	}, [showToast]);
	const copy = (0, import_react.useCallback)(async (value) => {
		try {
			await navigator.clipboard.writeText(value);
		} catch {
			const el = document.createElement("textarea");
			el.value = value;
			document.body.appendChild(el);
			el.select();
			document.execCommand("copy");
			el.remove();
		}
		showToast("Nomor rekening berhasil disalin!");
	}, [showToast]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen justify-center bg-muted",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "paper relative w-full max-w-[480px] overflow-hidden shadow-[0_0_60px_oklch(0.3_0.03_130/0.18)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("audio", {
					ref: audioRef,
					src: MUSIC_SRC,
					loop: true,
					preload: "none"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: `fixed inset-0 z-50 mx-auto flex max-w-[480px] transition-opacity duration-700 ${opened ? "pointer-events-none opacity-0" : "opacity-100"}`,
					"aria-hidden": opened,
					children: [[0, 1].map((side) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "relative h-full w-1/2 transition-transform duration-[1300ms] ease-[cubic-bezier(.76,0,.24,1)]",
						style: {
							background: side === 0 ? "linear-gradient(100deg, var(--sage-deep), var(--sage) 70%)" : "linear-gradient(260deg, var(--sage-deep), var(--sage) 70%)",
							transform: opened ? `translateX(${side === 0 ? "-100%" : "100%"})` : "none",
							boxShadow: "inset 0 0 80px oklch(0.3 0.04 150 / 0.35)"
						}
					}, side)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: `absolute inset-0 flex flex-col items-center justify-center px-8 text-center transition-opacity duration-500 ${opened ? "opacity-0" : "opacity-100"}`,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-xs tracking-[0.42em] text-primary-foreground/85",
								children: "THE WEDDING OF"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
								className: "mt-3 font-script text-4xl leading-tight text-primary-foreground drop-shadow-sm",
								children: [
									COUPLE.groom.short,
									" & ",
									COUPLE.bride.short
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 font-display text-sm tracking-[0.24em] text-primary-foreground/85",
								children: EVENT.dateLabel.toUpperCase()
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: open,
								className: "group mt-12 flex flex-col items-center",
								"aria-label": "Buka undangan",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: seal_default,
									alt: "",
									width: 512,
									height: 512,
									className: "h-28 w-28 [animation:sealPulse_3.2s_ease-in-out_infinite]"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-7 rounded-full border border-primary-foreground/60 px-7 py-2 font-display text-xs tracking-[0.3em] text-primary-foreground transition-colors group-hover:bg-primary-foreground/15",
									children: "BUKA UNDANGAN"
								})]
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "relative flex min-h-screen flex-col items-center justify-between overflow-hidden pt-16",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "relative z-10 px-8 text-center",
						children: opened && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-[11px] tracking-[0.4em] text-muted-foreground opacity-0 [animation:softFade_1.2s_ease-out_.3s_forwards]",
								children: "TOGETHER WITH OUR FAMILIES"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 font-display text-lg italic tracking-wide text-sage-deep opacity-0 [animation:riseIn_1.2s_ease-out_.9s_forwards]",
								children: "You're Invited"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
								className: "mt-6 font-script text-[42px] leading-[1.15] text-foreground opacity-0 [animation:riseIn_1.3s_ease-out_1.5s_forwards]",
								children: [
									COUPLE.groom.short,
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mx-2 font-display text-2xl italic text-sage",
										children: "&"
									}),
									COUPLE.bride.short
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-5 font-display text-sm tracking-[0.32em] text-muted-foreground opacity-0 [animation:riseIn_1.2s_ease-out_2.1s_forwards]",
								children: "18 . 09 . 2026"
							})
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative w-full",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-x-0 -top-6 h-24 bg-gradient-to-b from-background to-transparent" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Butterfly, { style: {
								top: "-70px",
								left: "16%",
								color: "var(--wisteria)",
								animation: "flutter 11s ease-in-out infinite"
							} }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Butterfly, { style: {
								top: "-140px",
								right: "18%",
								color: "var(--sage-deep)",
								animation: "flutter 14s ease-in-out infinite 1.5s"
							} }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: garden_default,
								alt: "Ilustrasi cat air taman dengan gazebo dan bunga wisteria",
								width: 1024,
								height: 1024,
								className: "w-full [animation:swayLeaf_9s_ease-in-out_infinite] origin-bottom"
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "relative overflow-hidden pb-14",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: wisteria_default,
							alt: "",
							width: 1024,
							height: 512,
							loading: "lazy",
							className: "pointer-events-none absolute inset-x-0 top-0 w-full opacity-95"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: mountains_default,
							alt: "",
							width: 1024,
							height: 1024,
							loading: "lazy",
							className: "pointer-events-none absolute inset-x-0 bottom-0 w-full opacity-70"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative z-10 px-8 pt-40 text-center",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-display text-lg italic text-sage-deep",
									children: "Assalamu'alaikum Wr. Wb."
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mx-auto mt-4 max-w-[300px] font-display text-sm leading-relaxed text-muted-foreground",
									children: "Dengan memohon rahmat dan ridho Allah SWT, kami mengundang Bapak/Ibu/Saudara/i untuk hadir dan memberikan doa restu pada pernikahan kami."
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
									delay: 120,
									className: "mt-12",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-script text-4xl text-foreground",
										children: COUPLE.groom.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 font-display text-xs tracking-wide text-muted-foreground",
										children: COUPLE.groom.parents
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
									delay: 200,
									className: "my-7",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-script text-3xl text-sage",
										children: "&"
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
									delay: 260,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-script text-4xl text-foreground",
										children: COUPLE.bride.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 font-display text-xs tracking-wide text-muted-foreground",
										children: COUPLE.bride.parents
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
									delay: 160,
									className: "mt-14",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "rounded-2xl border border-border/70 bg-card/75 px-6 py-7 backdrop-blur-[2px]",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "font-display text-xl italic text-sage-deep",
												children: EVENT.title
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "mt-3 font-display text-base font-semibold tracking-wide",
												children: [
													EVENT.day,
													", ",
													EVENT.dateLabel
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "font-display text-sm text-muted-foreground",
												children: EVENT.timeLabel
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto my-5 h-px w-16 bg-border" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "font-display text-sm font-semibold",
												children: EVENT.venue
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-1 font-display text-sm leading-relaxed text-muted-foreground",
												children: EVENT.address
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "mt-6 flex flex-col gap-3",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
													href: MAPS_URL,
													target: "_blank",
													rel: "noreferrer",
													className: "rounded-full bg-primary px-5 py-2.5 font-display text-xs tracking-[0.22em] text-primary-foreground transition-opacity hover:opacity-90",
													children: "LIHAT LOKASI"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
													href: CALENDAR_URL,
													target: "_blank",
													rel: "noreferrer",
													className: "rounded-full border border-primary px-5 py-2.5 font-display text-xs tracking-[0.22em] text-sage-deep transition-colors hover:bg-accent",
													children: "SIMPAN TANGGAL"
												})]
											})
										]
									})
								})
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "relative flex min-h-[85vh] items-center justify-center overflow-hidden py-16",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: archway_default,
						alt: "",
						width: 720,
						height: 1024,
						loading: "lazy",
						className: "pointer-events-none absolute inset-0 h-full w-full object-cover opacity-60"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "relative z-10 mx-auto w-full max-w-[430px] px-6 text-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-2xl border border-border/75 bg-card/85 px-6 py-8 shadow-sm backdrop-blur-md",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "font-display text-base sm:text-lg font-medium italic leading-relaxed text-foreground",
									children: [
										"“",
										QURAN.text,
										"”"
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto my-5 h-px w-16 bg-sage/50" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-display text-xs font-semibold tracking-[0.25em] text-sage-deep",
									children: QURAN.source
								})
							]
						}) })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "relative px-6 py-20",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative mx-auto max-w-[420px] overflow-hidden rounded-2xl border border-border/70 bg-card/70 px-2 py-8 backdrop-blur-[2px]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: pines_default,
								alt: "",
								width: 512,
								height: 512,
								loading: "lazy",
								className: "pointer-events-none absolute -left-6 bottom-0 z-0 w-20 opacity-60"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: pines_default,
								alt: "",
								width: 512,
								height: 512,
								loading: "lazy",
								className: "pointer-events-none absolute -right-6 bottom-0 z-0 w-20 -scale-x-100 opacity-60"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "relative z-10 mb-6 text-center font-display text-xs tracking-[0.34em] text-muted-foreground",
								children: "MENUJU HARI BAHAGIA"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "relative z-10",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Countdown, {})
							})
						]
					}) })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "relative pb-24",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-b-[140px] bg-cocoa px-8 pb-20 pt-14 text-center",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
									className: "font-script text-3xl text-gold",
									children: "Kado Digital"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mx-auto mt-3 max-w-[280px] font-display text-sm leading-relaxed text-cocoa-foreground/85",
									children: "Jika berkenan memberikan hadiah personal, bisa dikirim melalui rekening berikut."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-7 space-y-4",
									children: ACCOUNTS.map((acc) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "rounded-xl bg-card px-5 py-4 text-left",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "font-display text-xl font-semibold tracking-[0.06em] text-foreground",
												children: acc.number
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "font-display text-sm text-muted-foreground",
												children: [
													"a.n. ",
													acc.holder,
													" / ",
													acc.bank
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												onClick: () => copy(acc.number),
												className: "mt-3 w-full rounded-full bg-primary px-4 py-2 font-display text-[11px] tracking-[0.22em] text-primary-foreground transition-opacity hover:opacity-90",
												children: "SALIN NOMOR REKENING"
											})
										]
									}, acc.number))
								})
							]
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
							className: "mt-14 px-8 text-center",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
								className: "font-script text-3xl text-sage-deep",
								children: "Hormat Kami"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-4 space-y-1.5 font-display text-base",
								children: FAMILY.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: n }, n))
							})] })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
							className: "mt-12 px-6",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WishesForm, { onNotify: showToast })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
							className: "mt-14 px-8 text-center",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-sm italic text-muted-foreground",
								children: "Wassalamu'alaikum Wr. Wb."
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-10 font-script text-2xl text-sage",
								children: "Save The Date"
							})] })
						})
					]
				}),
				opened && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: toggleMusic,
					"aria-label": playing ? "Jeda musik" : "Putar musik",
					className: "fixed bottom-6 right-[max(1.5rem,calc(50vw-240px+1.5rem))] z-40 flex h-12 w-12 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-lg transition-transform hover:scale-105",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: playing ? "animate-spin [animation-duration:4s]" : "",
						children: playing ? "❚❚" : "♫"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					role: "status",
					"aria-live": "polite",
					className: `pointer-events-none fixed bottom-24 left-1/2 z-50 -translate-x-1/2 rounded-full bg-cocoa px-5 py-2.5 font-display text-sm text-cocoa-foreground shadow-lg transition-all duration-300 ${toast ? "opacity-100" : "translate-y-3 opacity-0"}`,
					children: toast ?? ""
				})
			]
		})
	});
}
//#endregion
export { Invitation as component };
